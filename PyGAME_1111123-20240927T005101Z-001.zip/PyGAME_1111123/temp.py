
import tkinter as tk
from PIL import Image, ImageTk
from random import randint


window = tk.Tk()
window.title('抽籤遊戲')
window.geometry('300x400')

lottery = ['大吉','中吉','小吉']
label = [None]*3

cvs = tk.Canvas(window , width=500, height = 400)
img_PIL = Image.open('bg_lottery.png')
img = ImageTk.PhotoImage(img_PIL)
img.pack()

def click_btn():
    i = random.randint(0,2)
    label[i] = tk.Label(frame, text = lottery[i])

btn = tk.Button(window, text = '抽籤', command =click_btn)
btn.pack()

frame = tk.Frame(window)
frame.pack()

frame.pack(side = tk.TOP)


window.mainloop()