# -*- coding: utf-8 -*-
"""
電腦視覺
"""

# 讀取圖片
# 錯誤:單雙引號 斜線 全英文路徑

import cv2 as cv


img = cv.imread("C:/Lenna/Lenna-color.jpg")

dimensions = img.shape
total_number_of_elements = img.size

image_dtype = img.dtype

cv.imshow('Lenna-color', img)
cv.waitKey(0)
cv.destroyAllWindows()

b, g, r = cv.split(img)
rgb_image= cv.merge([r,g, b])

cv.imshow('rgb_image',rgb_image)
cv.waitKey(0)
cv.destroyAllWindows()

gray_img = cv.imread("C:/Lenna/Lenna-color.jpg")
cv.waitKey(0)
cv.destroyAllWindows()


