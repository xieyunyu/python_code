"""
電腦視覺0320
"""

import cv2 as cv
import numpy as np
#import matplotlib.pyplot as plt


img = cv.imread("C:/Lenna/Lenna-color.jpg")
height, width = img.shape[:2]
pts_1 = np.float32([[35, 45],[60, 45],[135, 230]])
pts_2 = np.float32([[135, 45],[120, 66],[150,230]])
M = cv.getAffineTransform(pts_1, pts_2)
affine_img = cv.warpAffine(img, M, (height, width))

#_________________________________________________
crop_img = img[80:200, 130:310]

cv.imshow('crop_img', crop_img)
cv.waitKey(0)
cv.destroyAllWindows()

#blur 模糊化>>區塊化__________________________________
avg_blur_img = cv.blur(img,(7,5))

cv.imshow('avg_blur_img', avg_blur_img)
cv.waitKey(0)
cv.destroyAllWindows()

#_________________________________________

bilateralFilter_img = cv.bilateralFilter(img, 5, 10, 10)

cv.imshow('bilateralFilter_img', bilateralFilter_img)
cv.waitKey(0)
cv.destroyAllWindows()

#高斯模糊____________________________________
smooth_image_gb = cv.GaussianBlur(img, (9, 9), 20)

cv.imshow('smooth_image_gb ', smooth_image_gb )
cv.waitKey(0)

#___________________________________________


smoothed = cv.GaussianBlur(img, (9, 9), 10)
unsharped = cv.addWeighted(img, 1.5, smoothed, -0.5, 0)

cv.imshow('unsharped ', unsharped )
cv.waitKey(0)
cv.destroyAllWindows()

#___________________________________________


M = np.ones(img.shape, dtype="uint8") * 60
added_image = cv.add(img, M)

cv.imshow('added_image', added_image )
cv.waitKey(0)
cv.destroyAllWindows()

#__________________________________________

scalar = np.ones((1, 3), dtype="float") * 110
added_image_2 = cv.add(img, scalar)

cv.imshow('added_image_2', added_image_2 )
cv.waitKey(0)
cv.destroyAllWindows()

#____________________________________


scalar = np.ones((1, 3), dtype="float") * 110
subtracted_image_2 = cv.subtract(img, scalar)

cv.imshow('subtracted_image_2', subtracted_image_2 )
cv.waitKey(0)
cv.destroyAllWindows()
















