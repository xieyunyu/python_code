"""
20230313電腦視覺
"""

import cv2 as cv
import numpy as np


img = cv.imread("C:/Lenna/Lenna-color.jpg")

cv.imshow('Lenna-color', img)
cv.waitKey(0)
cv.destroyAllWindows()

resized_img = cv.resize(img,(100,100),interpolation=cv.INTER_LINEAR)
cv.imshow('resized_img',resized_img)
cv.waitKey(0)
cv.destroyAllWindows()

#################################

dst_img = cv.resize(img,None, fx = 0.5, fy = 0.5,interpolation = cv.INTER_LINEAR)
cv.imshow('dst_img',dst_img)
cv.waitKey(0)
cv.destroyAllWindows()

#################################
M = np.float32([[1,0, 100],[0,1, 100]])
warpAffine_img = cv.warpAffine(img,M,(420,460))

cv.imshow('warpAffine_img',warpAffine_img)
cv.waitKey(0)
cv.destroyAllWindows()

#################################





